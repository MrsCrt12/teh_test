function searchFunction(terms) {
    //clear the div if input don't have val
    if (terms.length == 0) {
        document.getElementById("result").innerHTML = "";
        return;
    } else {
        //create a new request
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            //if it's succes
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("result").innerHTML = this.responseText;
            }
        };
        //the route with parameter
        xmlhttp.open("GET", "search/" + terms, true);
        xmlhttp.send();
    }
}