<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Person;
use Illuminate\Support\Facades\DB;

class PersonsController extends Controller
{
    //this is the function search
    public function search(Request $request){
        //check if requested parameter have 2 words
        $search = explode(' ',$request->terms);
        //if is looking for first name and last name
        if(!empty($search[1])){
            $persons =DB::table('persons')
                ->select(\DB::raw('SUBSTRING_INDEX(full_name, CHAR(9), 1) as first_name, SUBSTRING_INDEX(full_name, CHAR(9), -1) as last_name'))
                ->where('full_name','LIKE',\DB::raw("concat('".$search[0]."', char(9), '".$search[1]."%')"))
                ->orderBy('last_name')
                ->orderBy('first_name')
                ->get();
            //show the results
            foreach ($persons as $person){
                echo $person->first_name.' '.$person->last_name.'<br>';
            }

        }
        //if is looking for first name
        else{
            $persons = Person::select('full_name')
                ->where('full_name','LIKE',$search[0].'%')
                // to can search only with last name
                //->where('full_name','LIKE','%'.$search[0].'%')
                ->distinct()
                ->get();
            //show the results
            foreach ($persons as $person){
                echo $person->full_name. '<br>';
            }
        }

    }

}
